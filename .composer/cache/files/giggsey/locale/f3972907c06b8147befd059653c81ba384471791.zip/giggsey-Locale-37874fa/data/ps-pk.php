<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'PS' => 'فلسطين سيمے',
  'TC' => 'د ترکیے او کیکاسو ټاپو',
  'TF' => 'د فرانسے جنوبي سیمے',
);
