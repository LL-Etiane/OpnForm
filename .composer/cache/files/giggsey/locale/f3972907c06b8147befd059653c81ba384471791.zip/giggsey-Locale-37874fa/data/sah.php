<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'Бразилия',
  'CA' => 'Канаада',
  'CL' => 'Чиили',
  'CN' => 'Кытай',
  'CU' => 'Кууба',
  'EE' => 'Эстония',
  'FI' => 'Финляндия',
  'GB' => 'Улуу Британия',
  'IE' => 'Ирландия',
  'IM' => 'Мэн арыы',
  'IS' => 'Исландия',
  'JM' => 'Дьамаайка',
  'LT' => 'Литва',
  'LV' => 'Латвия',
  'LY' => 'Лиибийэ',
  'MX' => 'Миэксикэ',
  'NO' => 'Норвегия',
  'RU' => 'Арассыыйа',
  'SD' => 'Судаан',
  'SE' => 'Швеция',
  'US' => 'Америка Холбоһуктаах Штааттара',
);
