<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'Brazil',
  'CN' => 'China',
  'DE' => 'Germany',
  'ET' => 'Itoophiyaa',
  'FR' => 'France',
  'GB' => 'United Kingdom',
  'IN' => 'India',
  'IT' => 'Italy',
  'JP' => 'Japan',
  'KE' => 'Keeniyaa',
  'RU' => 'Russia',
  'US' => 'United States',
);
