<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AC' => 'Isla Ascensión',
  'AX' => 'Islas Åland',
  'BA' => 'Bosnia-Herzegovina',
  'CG' => 'República del Congo',
  'CI' => 'Costa de Marfil',
  'GS' => 'Islas Georgia del Sur y Sándwich del Sur',
  'IC' => 'Islas Canarias',
  'RO' => 'Rumania',
  'SA' => 'Arabia Saudita',
  'TL' => 'Timor Oriental',
  'UM' => 'Islas Ultramarinas de EE.UU.',
);
