<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'CG' => 'Kongo',
  'CV' => 'Kabo Verde',
  'CZ' => 'Češka Republika',
  'HK' => 'SAR Hongkong',
  'KN' => 'Sveti Kits i Nevis',
  'MO' => 'SAR Makao',
  'PM' => 'Sveti Pjer i Mikelon',
  'RE' => 'Reunion',
  'UM' => 'Manja udaljena ostrva SAD',
  'VC' => 'Sveti Vinsent i Grenadini',
);
