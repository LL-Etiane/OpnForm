# Release Notes

## [Unreleased](https://github.com/laravel/vapor-core/compare/v2.33.2...2.0)

## [v2.33.2](https://github.com/laravel/cashier/compare/v2.33.1...v2.33.2) - 2023-10-03

* [2.x] Adds helpers to determine when an app is running on Vapor  by @joedixon in https://github.com/laravel/vapor-core/pull/164
