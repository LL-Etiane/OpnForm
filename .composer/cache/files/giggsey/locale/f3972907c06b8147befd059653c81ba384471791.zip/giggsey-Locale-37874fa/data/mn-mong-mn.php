<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'ᠪᠷᠠᠽᠢᠯ',
  'CN' => 'ᠬᠢᠳᠠᠳ',
  'DE' => 'ᠭᠧᠷᠮᠠᠨ',
  'FR' => 'ᠫᠷᠠᠨ᠋᠋ᠼᠠ',
  'GB' => 'ᠶᠡᠺᠡ ᠪᠷᠢᠲ᠋ᠠᠨᠢ',
  'IN' => 'ᠡᠨᠡᠳᠬᠡᠭ᠌',
  'IT' => 'ᠢᠲ᠋ᠠᠯᠢ',
  'JP' => 'ᠶᠠᠫᠣᠨ',
  'MN' => 'ᠮᠣᠩᠭᠣᠯ',
  'RU' => 'ᠣᠷᠣᠰ',
  'US' => 'ᠠᠮᠸᠷᠢᠻᠠ ᠎ᠢᠢᠨ ᠨᠢᠭᠡᠳᠥᠭᠰᠡᠠ ᠡᠣᠯᠣᠰ',
);
