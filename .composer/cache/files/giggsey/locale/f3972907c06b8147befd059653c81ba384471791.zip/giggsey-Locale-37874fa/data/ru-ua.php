<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AC' => 'О-в Вознесения',
  'AE' => 'Объединенные Арабские Эмираты',
  'CK' => 'О-ва Кука',
  'CX' => 'О-в Рождества',
  'NF' => 'О-в Норфолк',
  'TL' => 'Тимор-Лесте',
  'UM' => 'Малые Тихоокеанские Отдаленные Острова США',
);
