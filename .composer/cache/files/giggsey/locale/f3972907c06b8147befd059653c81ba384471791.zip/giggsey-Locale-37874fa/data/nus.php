<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AD' => 'Andora',
  'AF' => 'Abganithtan',
  'AG' => 'Antiguaa kɛnɛ Barbuda',
  'AI' => 'Aŋguɛla',
  'AL' => 'Albänia',
  'AM' => 'Aɛrmänia',
  'AO' => 'Aŋgola',
  'AR' => 'Aɛrgentin',
  'AS' => 'Amerika thamow',
  'AT' => 'Athtɛria',
  'AU' => 'Athɔra̱lia',
  'AW' => 'Aruba',
  'AZ' => 'Adhe̱rbe̱ja̱n',
  'BA' => 'Bothnia kɛnɛ ɣärgobinia',
  'BB' => 'Bärbadoth',
  'BD' => 'Bengeladiec',
  'BE' => 'Be̱lgim',
  'BF' => 'Burkinɛ pa̱thu',
  'BG' => 'Bulga̱a̱ria',
  'BH' => 'Ba̱reen',
  'BI' => 'Burundi',
  'BJ' => 'Be̱ni̱n',
  'BM' => 'Be̱rmudaa',
  'BN' => 'Burunɛy',
  'BO' => 'Bulibia',
  'BR' => 'Bäraadhiil',
  'BS' => 'Bämuɔth',
  'BT' => 'Buta̱n',
  'BW' => 'Bothiwaana',
  'BY' => 'Be̱lɛruth',
  'BZ' => 'Bilidha',
  'CA' => 'Känɛda',
  'CF' => 'Cɛntrɔl aprika repuɔblic',
  'CG' => 'Kɔŋgɔ',
  'CI' => 'Kodibo̱o̱',
  'CK' => 'Kuk ɣa̱ylɛn',
  'CL' => 'Cili̱',
  'CM' => 'Kɛmɛrun',
  'CN' => 'Cayna',
  'CO' => 'Kolombia',
  'CR' => 'Kothtirika',
  'CV' => 'Kɛp bedi ɣa̱ylɛn',
  'DZ' => 'Algeria',
  'HR' => 'Korwaatia',
  'KH' => 'Kombodia',
  'KM' => 'Komruth',
  'KY' => 'Kaymɛn ɣa̱ylɛn',
  'SD' => 'Sudan',
  'TD' => 'Ca̱d',
  'VG' => 'Burutic dhuɔ̱ɔ̱l be̱rgin',
);
