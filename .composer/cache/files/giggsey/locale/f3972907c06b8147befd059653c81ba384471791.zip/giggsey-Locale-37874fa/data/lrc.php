<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'بئرئزیل',
  'CN' => 'چین',
  'DE' => 'آلمان',
  'FR' => 'فأرانسە',
  'GB' => 'بیریتانیا گأپ',
  'IN' => 'ھئن',
  'IT' => 'ئیتالیا',
  'JP' => 'جاپوٙن',
  'RU' => 'روٙسیە',
  'US' => 'ڤولاتیا یأکاگئرتە',
);
