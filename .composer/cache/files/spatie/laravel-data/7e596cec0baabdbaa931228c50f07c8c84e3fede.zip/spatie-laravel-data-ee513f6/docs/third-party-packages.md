---
title: Third party packages
weight: 5
---

Some community members created packages that extend the functionality of Laravel Data. Here's a list of them:

- [laravel-typescript-transformer](https://github.com/spatie/laravel-typescript-transformer)
- [laravel-data-openapi-generator](https://github.com/xolvionl/laravel-data-openapi-generator)

Created a package yourself that you want to add to this list? Send us a PR!
