<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AU' => 'Nūhōlani',
  'CA' => 'Kanakā',
  'CN' => 'Kina',
  'DE' => 'Kelemānia',
  'DK' => 'Kenemaka',
  'ES' => 'Kepania',
  'FR' => 'Palani',
  'GB' => 'Aupuni Mōʻī Hui Pū ʻIa',
  'GR' => 'Helene',
  'IE' => 'ʻIlelani',
  'IL' => 'ʻIseraʻela',
  'IN' => 'ʻĪnia',
  'IT' => 'ʻĪkālia',
  'JP' => 'Iāpana',
  'MX' => 'Mekiko',
  'NL' => 'Hōlani',
  'NZ' => 'Aotearoa',
  'PH' => 'ʻĀina Pilipino',
  'RU' => 'Lūkia',
  'US' => 'ʻAmelika Hui Pū ʻIa',
);
