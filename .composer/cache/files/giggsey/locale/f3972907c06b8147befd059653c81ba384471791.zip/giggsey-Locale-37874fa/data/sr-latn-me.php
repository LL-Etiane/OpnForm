<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BY' => 'Bjelorusija',
  'CG' => 'Kongo',
  'CZ' => 'Češka Republika',
  'DE' => 'Njemačka',
  'KN' => 'Sveti Kits i Nevis',
  'PM' => 'Sveti Pjer i Mikelon',
  'RE' => 'Reunion',
  'UM' => 'Manja udaljena ostrva SAD',
  'VC' => 'Sveti Vinsent i Grenadini',
  'VG' => 'Britanska Djevičanska Ostrva',
  'VI' => 'Američka Djevičanska Ostrva',
);
