<?php

namespace Spatie\LaravelData\Support\Validation;

abstract class ValidationRule
{
}
