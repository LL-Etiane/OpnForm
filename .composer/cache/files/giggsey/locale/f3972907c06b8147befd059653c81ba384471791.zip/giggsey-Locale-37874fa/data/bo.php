<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'CN' => 'རྒྱ་ནག',
  'DE' => 'འཇར་མན་',
  'GB' => 'དབྱིན་ཇི་',
  'IN' => 'རྒྱ་གར་',
  'IT' => 'ཨི་ཀྲར་ལི་',
  'JP' => 'ཉི་ཧོང་',
  'KR' => 'ལྷོ་ཀོ་རི་ཡ།',
  'NP' => 'བལ་ཡུལ་',
  'RU' => 'ཨུ་རུ་སུ་',
  'US' => 'ཨ་མེ་རི་ཀ།',
);
