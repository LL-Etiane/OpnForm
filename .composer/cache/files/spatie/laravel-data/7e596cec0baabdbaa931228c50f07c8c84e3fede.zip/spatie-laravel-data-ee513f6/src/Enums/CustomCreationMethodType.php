<?php

namespace Spatie\LaravelData\Enums;

enum CustomCreationMethodType
{
    case None;
    case Object;
    case Collection;
}
