---
title: Requirements
weight: 3
---

This package requires:
- PHP 8.1 or higher 
- Laravel 10 or higher 
