<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'Бразили',
  'CN' => 'Китай',
  'DE' => 'Герман',
  'FR' => 'Франц',
  'GB' => 'Стыр Британи',
  'GE' => 'Гуырдзыстон',
  'IN' => 'Инди',
  'IT' => 'Итали',
  'JP' => 'Япон',
  'RU' => 'Уӕрӕсе',
  'US' => 'АИШ',
);
