<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AC' => 'جزيرة أسينشين',
  'EA' => 'سبتة ومليلية',
  'MO' => 'ماكاو الصينية (منطقة إدارية خاصة)',
  'MS' => 'مونتيسيرات',
  'UY' => 'أوروغواي',
);
