<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AC' => 'Asesan Kapuãma',
  'BL' => 'San Batulumeu',
  'BT' => 'Butan',
  'CR' => 'Koñta Rika',
  'GA' => 'Gaban',
  'KN' => 'San Kirituwan suí Newi',
  'PM' => 'San Peduru asuí Mikelan',
  'TA' => 'Tiritan Kũya',
);
