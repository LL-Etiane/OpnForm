<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'Brasil',
  'CN' => 'Tiongkok',
  'DE' => 'Jérman',
  'FR' => 'Prancis',
  'GB' => 'Britania Raya',
  'ID' => 'Indonesia',
  'IN' => 'India',
  'IT' => 'Italia',
  'JP' => 'Jepang',
  'RU' => 'Rusia',
  'US' => 'Amérika Sarikat',
);
