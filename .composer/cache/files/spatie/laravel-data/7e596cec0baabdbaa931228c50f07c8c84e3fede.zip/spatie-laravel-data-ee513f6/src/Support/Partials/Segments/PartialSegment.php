<?php

namespace Spatie\LaravelData\Support\Partials\Segments;

use Stringable;

abstract class PartialSegment implements Stringable
{
}
