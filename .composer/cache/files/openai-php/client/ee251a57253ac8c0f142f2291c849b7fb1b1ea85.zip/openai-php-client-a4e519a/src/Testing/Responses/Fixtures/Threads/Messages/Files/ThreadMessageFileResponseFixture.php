<?php

namespace OpenAI\Testing\Responses\Fixtures\Threads\Messages\Files;

final class ThreadMessageFileResponseFixture
{
    public const ATTRIBUTES = [
        'id' => 'file-DhxjnFCaSHc4ZELRGKwTMFtI',
        'object' => 'thread.message.file',
        'created_at' => 1_699_624_660,
        'message_id' => 'msg_KNsDDwE41BUAHhcPNpDkdHWZ',
    ];
}
