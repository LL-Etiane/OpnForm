<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BY' => 'Бјелорусија',
  'CG' => 'Конго',
  'CZ' => 'Чешка Република',
  'DE' => 'Њемачка',
  'KN' => 'Свети Китс и Невис',
  'PM' => 'Свети Пјер и Микелон',
  'RE' => 'Реунион',
  'UM' => 'Мања удаљена острва САД',
  'VC' => 'Свети Винсент и Гренадини',
  'VG' => 'Британска Дјевичанска Острва',
  'VI' => 'Америчка Дјевичанска Острва',
);
