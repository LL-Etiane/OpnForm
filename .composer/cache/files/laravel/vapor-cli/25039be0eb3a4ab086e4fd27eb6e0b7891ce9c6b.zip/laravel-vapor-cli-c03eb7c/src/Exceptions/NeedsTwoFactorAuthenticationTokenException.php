<?php

namespace Laravel\VaporCli\Exceptions;

use RuntimeException;

class NeedsTwoFactorAuthenticationTokenException extends RuntimeException
{
    //
}
