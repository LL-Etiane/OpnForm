<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'ब्राज़ील',
  'CN' => 'चीन',
  'DE' => 'जर्मन',
  'FR' => 'फ्रांस',
  'GB' => 'मुतहीद बादशाहत',
  'IN' => 'हिंदोस्तान',
  'IT' => 'इटली',
  'JP' => 'जापान',
  'RU' => 'रूस',
  'US' => 'मूतहीद रियासत',
);
