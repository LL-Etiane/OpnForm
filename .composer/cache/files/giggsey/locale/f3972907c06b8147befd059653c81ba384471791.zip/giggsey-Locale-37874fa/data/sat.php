<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'BR' => 'ᱵᱨᱟᱡᱤᱞ',
  'CN' => 'ᱪᱤᱱ',
  'DE' => 'ᱡᱟᱨᱢᱟᱱᱤ',
  'FR' => 'ᱯᱷᱨᱟᱱᱥ',
  'GB' => 'ᱭᱩᱱᱤᱭᱴᱮᱰ ᱠᱤᱝᱰᱚᱢ',
  'IN' => 'ᱤᱱᱰᱤᱭᱟ',
  'IT' => 'ᱤᱴᱞᱤ',
  'JP' => 'ᱡᱟᱯᱟᱱ',
  'RU' => 'ᱨᱩᱥ',
  'US' => 'ᱭᱩᱱᱟᱭᱴᱮᱰ ᱮᱥᱴᱮᱴ',
);
