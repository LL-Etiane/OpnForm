# Release Instructions

1. Update the version in [`vapor`](./vapor#L71) and commit it
2. [Create a new GitHub release](https://github.com/laravel/vapor-cli/releases/new) for this version with the release notes
