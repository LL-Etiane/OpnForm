<?php
/**
 * Locale @generated from CLDR version 45.0.0
 * See README.md for more information.
 *
 * @internal
 *
 * Do not modify or use this file directly!
 */

return array (
  'AX' => 'Islas Åland',
  'CG' => 'República del Congo',
  'CI' => 'Costa de Marfil',
  'EH' => 'Sahara Occidental',
  'GG' => 'Guernsey',
  'GS' => 'Islas Georgia del Sur y Sándwich del Sur',
  'IC' => 'Islas Canarias',
  'RO' => 'Rumania',
  'SA' => 'Arabia Saudita',
  'TL' => 'Timor Oriental',
);
